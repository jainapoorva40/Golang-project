# Contributors

<!-- prettier-ignore-start -->
Open Email Generator

- [Saputra](https://github.com/Svz1404)
- [Fajril Pratam](https://github.com/gabutteam18)
- [Robby Rohmana](https://github.com/gabutteam3a)
- [Verrnando](https://github.com/gabutteam3b)
- [Leviie](https://github.com/leviakeer212)
- [Hydeshy](https://github.com/ganutteam1)
- [Deepesh](https://github.com/dikshansh17)
- [Cinta Lakie](https://github.com/ganutteam2)
- [Muhamad Sadam](https://github.com/fajarmuhre)
- [Qioku Lahdan](https://github.com/ganutteam3)
- [Pratika Hastari](https://github.com/ganutteam4)
- [Roy](https://github.com/ehroy)
- [Kevin Rivaldo Panggabean](https://github.com/krpauto)
- [Mhd Arif Budiman](https://github.com/guebanget0?tab=repositories)
- [Anugerah](https://github.com/syncos77)
- [Salman](https://github.com/salfar17)

<!-- prettier-ignore-end -->
